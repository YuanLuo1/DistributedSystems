package commInfra;

import java.io.Serializable;

import clock.*;

public class TimeStampedMessage extends Message implements Serializable {
	String msgId;
	String group;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TimeStampedMessage(String dest, String kind, Object data) {
		super(dest, kind, data);
		timeStamp=null;
		// TODO Auto-generated constructor stub
	}
	
	private TimeStamp timeStamp;
	public void setTimeStamp(TimeStamp ts){
		timeStamp=ts;
	}
	
	public TimeStamp getTimeStamp(){
		return timeStamp;
	}
	
	public String toString(){
		String msg="Source: "+super.source+", Dest: "+super.destination+", kind: "+super.kind+", sequence: "+super.seqNum+", timestamp: "+timeStamp;
		if(null!=data){
			msg=msg+" data: "+data;
		}
		return msg;
	}

	public void setDest(String member) {
		destination = member;
	}
	public String sender(){
		return source;
	}
	public void setgGroup(String Group){
		this.group=Group;
	}
	public String getmsgId(){
		msgId=source.concat(""+seqNum);
		return msgId;
	}
}
