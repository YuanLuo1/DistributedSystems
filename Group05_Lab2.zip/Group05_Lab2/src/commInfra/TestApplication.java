/**
 * 
 */
package commInfra;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import com.dropbox.core.DbxException;

/**
 * @author PhaniShankar
 * Sample test application which uses MessagePasser framework
 */
public class TestApplication {

	private static void invokeUI(MessagePasser mp) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String line;
		TimeStampedMessage msg;
		
		while ((line = br.readLine())!= null){
			/* ignore empty string */
			if (line.length()<=0) continue;
			switch(line.charAt(0)){
			case 'q': return;
			
			case 'r': /* check for a received message */
					  msg = mp.receive();
					  if (null == msg){
						  System.out.println("Receive Queue Empty");
					  }
					  else{
						  System.out.println("Received message :" + msg);
					  }
					  break;
					  
			case 's': /* send a message */
					  String [] inputs = (line.split(":"))[1].split(",");	
					  msg =  new TimeStampedMessage(inputs[0],inputs[1],inputs[2]);
					  mp.send(msg);
					  break;
			case 'm':/* send a multicast message*/
					  String [] inputs1 = (line.split(":"))[1].split(",");	
				      msg =  new TimeStampedMessage(inputs1[0],inputs1[1],inputs1[2]);
			     	  mp.reliableMulticast(inputs1[0],msg);
			    	  break;
					  
			case 'h':
			default :
					 System.out.println("Help:\n q to quit. \n r to receive message \n s:dest,kind,data to send a message\n h: help "); 	
					 break; 					
			}	
		}
		
	}
	/**
	 * @param args
	 * @throws DbxException 
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException, DbxException {
		//System.out.println("Enter configuration file name");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		//String configFileName = br.readLine();
		System.out.println("Enter process name");
		String processName =  br.readLine();
		//System.out.println("Enter clocking system (logical or vector):");
		//String timing=br.readLine();
		//MessagePasser mp = new MessagePasser(configFileName, processName,timing);
		MessagePasser mp = new MessagePasser("/Users/luoyuan/Desktop/CommunicationInfrastructure/src/commInfra/config_file.txt", processName,"vector");
		invokeUI(mp);
		System.exit(0);
		///Users/luoyuan/Desktop/CommunicationInfrastructure/src/commInfra/config_file.txt
	}


}
