/**
 * 
 */
package commInfra;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import com.dropbox.core.DbxException;

/**
 * @author Yuan Luo
 * Configuration Manager is responsible for reading configuration file in YAML format and parsing it.
 */
public class ConfigurationManger {
	Map<String,List> configDict;
	String configFile;
	String processName;
	FileTime lastKnownModifiedTime;
	/**
	 * @throws IOException 
	 * 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public ConfigurationManger(String configFile, String processName) throws IOException {
		Yaml yaml = new Yaml();
		this.configFile = configFile;
		this.processName = processName;		
		try {
			Path path = Paths.get(configFile);
			BasicFileAttributes attr = Files.readAttributes(path, BasicFileAttributes.class);
			lastKnownModifiedTime = attr.lastModifiedTime();
			//System.out.println("lastKnownModifiedTime "+ lastKnownModifiedTime);
			InputStream input = new FileInputStream(new File(configFile));
			this.configDict = (Map<String,List>)yaml.load(input);
			System.out.println(configDict);		
			input.close();
		} catch (FileNotFoundException e) {
			System.out.println("Configuration File not Found. Initialization failed");
			e.printStackTrace();
			throw e;
		}
	}
	
	public synchronized Map<String,List> checkForUpdates() throws IOException{
		Yaml yaml = new Yaml();
		try {
			Path path = Paths.get(configFile);
			BasicFileAttributes attr = Files.readAttributes(path, BasicFileAttributes.class);
			FileTime lastModifiedTime  = attr.lastModifiedTime();
			if (lastKnownModifiedTime.equals(lastModifiedTime)){
				/* No updates since the last read. Return the same dictionary */
				//System.out.println("No updates");
				return configDict;
			}
			/* Check if modified time is after last read time, then only re-read the file */
			InputStream input = new FileInputStream(new File(configFile));
			Map<String,List> newConfigDict = (Map<String,List>)yaml.load(input);
			/* Update only the send and receive rules. Configuration should not be changed */
			this.configDict.put("sendRules", newConfigDict.get("sendRules"));
			this.configDict.put("receiveRules", newConfigDict.get("receiveRules"));
			//System.out.println(configDict);	
			input.close();
		} catch (FileNotFoundException e) {
			System.out.println("Configuration File not Found. Update failed");
			e.printStackTrace();
		}
		return configDict;
	}
}
