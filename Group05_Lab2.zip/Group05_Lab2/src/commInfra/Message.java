/**
 * 
 */
package commInfra;

import java.io.Serializable;

import clock.TimeStamp;

/**
 * @author PhaniShankar
 * Class that describes the message exchanged between nodes
 */
public class Message implements Serializable{
	/* Header */
	String source;
	String destination;
	String kind;
	int    seqNum;
	/* payload */
	Object data;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Message(String dest, String kind, Object data) {
		this.kind = kind;
		this.destination = dest;
		this.data = data;
	}

	public void set_source(String source){
		this.source = source;
	}
	
	public void set_seqNum(int sequenceNumber) {
		seqNum = sequenceNumber;
	}
	
	public String get_Source(){
		return source;
	}
	
	public String get_destination(){
		return destination;
	}
	public int get_seqNum(){
		return seqNum;
	}
	
	public String get_kind(){
		return kind;
	}
	
	public String toString(){
		String msg = "Source: "+ source + ", Dest: "+ destination + ", kind: "+kind +", seqNum: "+ seqNum;
		if (null != data){
			msg = msg + " data: "+ data;
		}
		return msg;
	}
}
