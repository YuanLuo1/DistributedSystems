/**
 * 
 */
package commInfra;

import java.io.*;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;

import clock.*;

import com.dropbox.core.DbxException;

/**
 * @author PhaniShankar
 * Class responsible for facilitating an environment where applications can send messages to other applications
 * running on other nodes. In addition, fine grained control of message passing can be achieved using 
 * rule specifications in configuration file
 */
public class MessagePasser {
	String  configFile;
	String  processName;
	String Group;
	ConfigurationManger cm;
	RulesEngine re;
	Map <String, ConnectionProperties> connectionMap = null;
	Object connectionMapLock;
	ServerSocket serverSocket;
	boolean isAppStopped;
	ClockService cs;
	ArrayList<String> memberList;
	private Object deliveryQueueLock = new Object();
	/**
	 * @throws DbxException 
	 * @throws IOException 
	 * 
	 */
	public MessagePasser(String configurationFilename, String localName,String timing) throws IOException, DbxException {
		this.configFile = configurationFilename;
		this.processName = localName;
		connectionMap = new HashMap<String,ConnectionProperties>();
		serverSocket = null;
		isAppStopped = false;
		connectionMapLock = new Object();
		/* Initialize CM and RE and read the configuration data */
		cm = new ConfigurationManger(configurationFilename,localName);
		re = new RulesEngine(cm);		
		if (cm.configDict == null){
			System.out.println("Empty configuration");
			System.exit(0);;
		}
		List initialConfig = (List)cm.configDict.get("configuration");
		if (timing.equals("logical")){
			cs=new LogicalClock();
			LogicalTime lt=(LogicalTime) cs.getTimeStamp().getTime();
			System.out.println("The initial clocl time is: "+lt.getLogicalTime());
		}
		if(timing.equals("vector")){
			int nodes=initialConfig.size();
			int id;
			switch(processName){
			case "alice":  	id=0;
			break;
			case "bob":    	id=1;
			break;
			case "charlie":	id=2;
			break;
			case "daphnie":	id=3;
			break;
			case "logger":	id=4;
			break;
			default:
				System.out.println("No configuration found for "+processName+".\nDirected to logger by default.");
				id=5;
				break;
				}
			cs=new VectorClock(nodes,id);
			VectorTime vt=(VectorTime) cs.getTimeStamp().getTime();
			System.out.println("The initial clock time is: ");
			for (int i=0;i<vt.getVectorSize();i++){
				System.out.println(vt.getVectorTime()[i]);
			}
		}
		
		try{
			setUpTCPConnections(initialConfig,localName);
			//System.out.println("Setup complete");
		}
		catch(IOException | InterruptedException e){
			System.out.println("TCP Connection setup failed");
			isAppStopped = true;	
		}
		
	}
	void send(TimeStampedMessage message){
		
		ConnectionProperties cp = null;
		cp = connectionMap.get(message.destination);
		
		if (null == cp ){
			System.out.println("WARNING: Attempting to send message to " + message.destination + " on non-existant connection ");
			return;
		}
		message.set_seqNum(cp.getSeqNum());
		cp.incSeqNum();
		message.set_source(this.processName);
		
		try {
			ArrayList<TimeStampedMessage> msgList = re.applySendRules(message,cs);
			if (null == msgList){
				/* Message delayed or dropped. No action needed */
				return;
			}
			else{
				for (TimeStampedMessage msg: msgList){
					/*Get the socket based on the destination */
					cp = connectionMap.get(msg.destination);
					cs.sendAction();
				   	msg.setTimeStamp(cs.getTimeStamp());
					if (null == cp ){
						System.out.println("WARNING: Attempting to send message to " + msg.destination + " on non-existant connection ");
						continue;
					}			
					/* send the message on the socket */
					cp.outputStream.writeObject(msg);
					System.out.println(msg);
					cp.outputStream.flush();
				}
			}
			
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Unable to send message : "+message);
		}
		
	}
	TimeStampedMessage receive(){
		return re.getRcvdMsg();
	}
	void reliableMulticast(String Group, TimeStampedMessage msg ) throws IOException{
		basicMulticast(Group, msg);
	}
	void basicMulticast(String Group, TimeStampedMessage msg) throws IOException{
		memberList = re.getGroupmembers(Group);
		msg.setgGroup(Group);
		this.Group=msg.group;
		for(String member: memberList){
				msg.setDest(member);
				send(msg);
		}
	}
	void basicDeliver(TimeStampedMessage msg){
		TimeStampedMessage msgs = null;
		synchronized(deliveryQueueLock){
			if (false == re.holdbackQueue.isEmpty()){
				re.holdbackQueue.remove(0);
				if(re.deliveryQueue.contains(msg)==false){
				re.deliveryQueue.add(0,msg);
				}
			//	msgs = re.deliveryQueue.remove(0);
			}
		}
	}
	void reliableDeliver(TimeStampedMessage msg) throws IOException{
		basicDeliver(msg);		
		}
	void reliableCheck(TimeStampedMessage msg, MessagePasser mp) throws IOException{
		/*if(msg.kind=="ack"){
			if(re.ackMap.containsKey(msg.msgId)==false){
				ArrayList<TimeStampedMessage> ackQueue = new ArrayList<TimeStampedMessage>();
				ackQueue.add(0,msg);
				re.ackMap.put(msg.msgId, ackQueue);
			}
			else{
				re.ackQueue.add(0,msg);
			    re.ackMap.put(msg.msgId, re.ackQueue);
			    re.groupMembers = re.getGroupmembers(msg.group);
			    if(re.ackQueue.size()==re.groupMembers.size()){
			    	//reliableDeliver(re.holdbackQueue);
			    }
			}
		}*/
		re.holdbackQueue.add(0,msg);
		System.out.println(re.holdbackQueue.contains(msg));
		reliableDeliver(msg);
		if(re.holdbackQueue.contains(msg)==false){
			re.holdbackQueue.add(0,msg);
			if(msg.destination.equals(msg.source)==false){
		//TimeStampedMessage ackMsg = new TimeStampedMessage(msg.source,"ack",null);
	//	mp.cs.sendAction();
	   //	msg.setTimeStamp(mp.cs.getTimeStamp());
		//ackMsg.msgId=msg.msgId;
		//basicMulticast(msg.group,msg);
			}
		reliableDeliver(msg);
			
		}
	}
	private boolean setUpTCPConnections(List initialConfig, String localProcessName) throws InterruptedException, IOException{
		for (int i =0; i < initialConfig.size();i++){
			Map configEntry = (Map)initialConfig.get(i);	
			String name = (String) configEntry.get("name");
			if (name.equals(localProcessName)){
				/*current process configuration. Open a TCP server at configured port */
				int port = (int)configEntry.get("port");
				try {
					serverSocket =  new ServerSocket(port);
					TcpServer server = new TcpServer(serverSocket,this);
					Thread serverThread = new Thread(server);
					serverThread.start();
					break;
				} catch (IOException e) {					
					System.out.println("Unable to create a TCP server. Initialization failed");
					return false;
				} 
			}			
		}
		
		for (int i =0; i < initialConfig.size();i++){
			Map configEntry = (Map)initialConfig.get(i);
			String name = (String) configEntry.get("name");
			/* Every process will establish connection with every other process whose 
			 * name is lexicographically greater than current process name*/
			if (name.compareTo(localProcessName) >= 0){
				/*create a connection with peer process */
				String ip = (String) configEntry.get("ip");
				int port = (int)configEntry.get("port");
				TCPConnectionCoordinator tcc = new TCPConnectionCoordinator(this,ip,port,name);  
				Thread tccThread = new Thread(tcc);
				tccThread.start();
			}			
		}	
		return true;
	}
}
