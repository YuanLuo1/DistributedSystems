/**
 * 
 */
package commInfra;

import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * @author PhaniShankar
 * Class describes per connection properties
 */
public class ConnectionProperties {
	Socket socket;
	int seqNum;
	ObjectOutputStream outputStream;
	/**
	 * 
	 */
	public ConnectionProperties(Socket socket, int seqNum, ObjectOutputStream outputStream) {
		this.seqNum = seqNum;
		this.socket = socket;	
		this.outputStream = outputStream;
	}
	public int getSeqNum(){
		return seqNum;
	}
	public void incSeqNum(){
		seqNum++;
	}
}
