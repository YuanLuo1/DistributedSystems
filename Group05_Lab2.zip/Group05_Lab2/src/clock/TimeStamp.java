package clock;

import java.io.Serializable;

public class TimeStamp implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public Time time;
	/*public int lessThan;
	public int isConcurren;
	public int greaterThan;
*/
	public TimeStamp(){
		time=new LogicalTime();
	}
	
	public TimeStamp(int proc, int Id){
		time=new VectorTime(proc,Id);
	}
	
	/*public Time getStamp(){
		time.tick();
		return time;
	}*/
	
	public Time getTime(){
		return time;
	}

	public boolean happensBefore(Time t){
		return time.happensBefore(t);
	}
	public boolean isConcurrent(Time t){
		VectorTime t1=(VectorTime) t;
		return t1.isConcurrent(t);
		//VectorTime time=(VectorTime) t;
		//time.isConcurrent(time);
	}
	public String toString(){
		String stamp=""+time.toString();
		return stamp;
	}

}
