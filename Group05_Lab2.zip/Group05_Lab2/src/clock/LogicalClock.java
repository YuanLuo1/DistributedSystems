package clock;

public class LogicalClock extends ClockService {
	
	public LogicalClock(){
		super();
	}
	
	public TimeStamp getTimeStamp(){
		return super.timeStamp;
	}
	public void tick(){
		super.timeStamp.getTime().tick();
	}
	public void sendAction(){
		tick();
	}
	public void receiveAction(TimeStamp ts){
		LogicalTime t=(LogicalTime)super.timeStamp.getTime();
		LogicalTime t2=(LogicalTime)ts.getTime();
		t.setLogicalTime(Math.max(t.getLogicalTime(), t2.getLogicalTime()));
		t.tick();
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.timeStamp.getTime().toString();
	}
}
