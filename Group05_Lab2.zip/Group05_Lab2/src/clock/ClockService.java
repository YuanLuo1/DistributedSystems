package clock;

public abstract class ClockService {
	protected TimeStamp timeStamp;

	public ClockService(){
		timeStamp=new TimeStamp();
	}
	
	public ClockService(int proc,int Id){
		timeStamp=new TimeStamp(proc, Id);
	}
	
	
public abstract TimeStamp getTimeStamp();
public abstract void tick();
public abstract void sendAction();
public abstract void receiveAction(TimeStamp ts);
public abstract String toString();

}


