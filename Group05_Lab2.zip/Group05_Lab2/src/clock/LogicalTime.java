package clock;

import java.io.Serializable;

public class LogicalTime implements Time,Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int Counter;
	
	public LogicalTime(){
		Counter=1;
	}
	public void tick(){
		Counter++;
	}
	public int getLogicalTime(){
		return Counter;
	}
	public void setLogicalTime(int value){
		Counter=value;
	}
	@Override
	public boolean happensBefore(Time time) {
		// TODO Auto-generated method stub
		LogicalTime t=(LogicalTime) time;
		if (Counter<t.Counter){
			return true;
		}
		return false;
	}
	public String toString(){
		return ""+Counter;
	}
}
