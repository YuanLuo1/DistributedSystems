/**
 * 
 */
package commInfra;

import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * @author Yuan Luo
 * Class describes per connection properties
 */
public class ConnectionProperties {
	Socket socket;
	int seqNum;
	Time timestamp;
	ObjectOutputStream outputStream;
	/**
	 * 
	 */
	public ConnectionProperties(Socket socket, int seqNum,Time timestamp, ObjectOutputStream outputStream) {
		this.seqNum = seqNum;
		this.socket = socket;
		this.timestamp=timestamp;
		this.outputStream = outputStream;
	}
	public int getSeqNum(){
		return seqNum;
	}
	public void incSeqNum(){
		seqNum++;
	}
	
}
