/**
 * 
 */
package commInfra;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author PhaniShankar
 * Class responsible for running a TCP server
 */
public class TcpServer implements Runnable {
	ServerSocket serverSocket;
	MessagePasser mp;
	
	public TcpServer(ServerSocket serverSocket, MessagePasser mp){
		this.serverSocket = serverSocket;
		this.mp = mp;
	}
	
	public void run(){
		System.out.println("Starting TCP Server");
		
		/* Accept the connection */
		while (false == mp.isAppStopped){
			try {
				Socket clientSocket = serverSocket.accept();
				/* create a thread to handle the connection */
				TcpRecieveMessageHandler handler = new TcpRecieveMessageHandler(mp,clientSocket);
				Thread clientThread = new Thread(handler);
				clientThread.start();				
			} catch (IOException e) {
				System.out.println("Accept failed:");
				mp.isAppStopped = true;
				e.printStackTrace();
				/* proceed with the next connection */
			}
		}
		if (serverSocket != null){
			try {
				serverSocket.close();
			} catch (IOException e) {
				mp.isAppStopped = true;
			}
		}
		for (ConnectionProperties entry:mp.connectionMap.values()){
			try {
				entry.socket.close();
			} catch (IOException e) {			
				e.printStackTrace();
				mp.isAppStopped = true;
			}
		}
	}
}
