package commInfra;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class MulticastSender {
	public static void main(String[] args) throws IOException
    {
        int port = 8888;
        byte[] msg = "Connection successfully!!!".getBytes();

        InetAddress inetRemoteAddr = InetAddress.getByName("228.5.6.7");
        MulticastSocket client = new MulticastSocket();

        DatagramPacket sendPack = new DatagramPacket(msg, msg.length,
                inetRemoteAddr, port);

        client.send(sendPack);

        System.out.println("Client send msg complete");

        client.close();

    }
}
