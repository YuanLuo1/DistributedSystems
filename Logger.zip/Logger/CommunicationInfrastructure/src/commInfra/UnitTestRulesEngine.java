/**
 * 
 */
package commInfra;

import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Logger;

import com.dropbox.core.DbxException;

/**
 * @author PhaniShankar
 * Unit testing application. Not part of production code
 */
public class UnitTestRulesEngine {

	/**
	 * 
	 */
	public UnitTestRulesEngine() {
		
	}
	
	private static void testSendRules(ConfigurationManger cm, RulesEngine re) throws IOException{
		/*req from bob to charlie . No match scenario*/
		TimeStampedMessage msg = new TimeStampedMessage("charlie","Request",null);
		msg.set_source("bob");
		msg.set_seqNum(1);
		
		ArrayList<TimeStampedMessage> msgList = re.applySendRules(msg);
		assert msgList.size()==1;
		assert msgList.get(0) == msg;
		System.out.println(msgList.size());
		
		/*Ack 4 from bob to alice . drop message */
		msg = new TimeStampedMessage("alice","Ack",null);
		msg.set_source("bob");
		msg.set_seqNum(4);
		
		msgList = re.applySendRules(msg);
		assert msgList.size()==0;
		System.out.println(msgList.size());
		
		/*Ack 4 from daphnie to alice . No match scenario*/
		msg = new TimeStampedMessage("alice","Ack",null);
		msg.set_source("daphnie");
		msg.set_seqNum(4);
		
		msgList = re.applySendRules(msg);
		assert msgList.size()==1;
		System.out.println(msgList.size());
	
		/*Ack 7 from daphnie to alice . Drop After scenario*/
		msg = new TimeStampedMessage("alice","Reply",null);
		msg.set_source("daphnie");
		msg.set_seqNum(7);
		
		msgList = re.applySendRules(msg);
		assert msgList.size()==0;
		System.out.println(msgList.size());
		
		/* daphnie to charlie Reply below seqNum for drop after rule. No match*/
		msg = new TimeStampedMessage("charlie","Reply",null);
		msg.set_source("daphnie");
		msg.set_seqNum(5);
		
		msgList = re.applySendRules(msg);
		assert msgList.size()==1;
		System.out.println(msgList.size());
		
		/* Source Charlie. Delay message*/
		msg = new TimeStampedMessage("bob","Reply",null);
		msg.set_source("charlie");
		msg.set_seqNum(5);
		
		msgList = re.applySendRules(msg);
		assert msgList.size()==0;
		System.out.println(msgList.size());
		
		/* daphnie to charlie Reply below seqNum for drop after rule. No match*/
		msg = new TimeStampedMessage("bob","Request",null);
		msg.set_source("charlie");
		msg.set_seqNum(5);
		
		msgList = re.applySendRules(msg);
		assert msgList.size()==0;
		System.out.println(msgList.size());
		
		LogMsgLists(re);
		
		/* daphnie to charlie Reply below seqNum for drop after rule. No match*/
		msg = new TimeStampedMessage("charlie","Reply",null);
		msg.set_source("daphnie");
		msg.set_seqNum(5);
		
		msgList = re.applySendRules(msg);
		assert msgList.size()==3;
		System.out.println(msgList.size());
		
		System.out.println("Returned List");
		for (Message msgEntry: msgList){
			System.out.println(msgEntry);
		}
		LogMsgLists(re);
	}
	/**
	 * @param args
	 * @throws IOException 
	 * @throws DbxException 
	 */
	public static void main(String[] args) throws IOException, DbxException {
		ConfigurationManger cm = new ConfigurationManger("/config_file.txt","alice");
		RulesEngine re = new RulesEngine(cm);
		//testSendRules(cm,re);
		//testRcvRules(cm,re);
		
		TimeStampedMessage msg = new TimeStampedMessage("bob","Reply",null);
		msg.set_source("daphnie");
		msg.set_seqNum(7);
		re.applySendRules(msg);
	}

	private static void LogMsgLists(RulesEngine re){
		System.out.println("Rcvd message list size " + re.rcvdMsgList.size());
		System.out.println("Delayed Rcvd message list size " + re.delayedRcvdMsgList.size());
		System.out.println("Delayed Sent message list size " + re.delayedSendMsgList.size());
		
		System.out.println("Rcvd message list ");
		for (Message msg : re.rcvdMsgList){
			System.out.println(msg);
		}
		
		System.out.println("Delayed Rcvd message list");
		for (Message msg : re.delayedRcvdMsgList){
			System.out.println(msg);
		}
		
		System.out.println("Delayed Sent message list");
		for (Message msg : re.delayedSendMsgList){
			System.out.println(msg);
		}
	}
	
	private static void testRcvRules(ConfigurationManger cm, RulesEngine re) throws IOException {
		TimeStampedMessage msg = new TimeStampedMessage("charlie","Request",null);
		msg.set_source("bob");
		msg.set_seqNum(1);
		
		re.applyReceiveRules(msg);
		//assert re.getRcvdMsg() == msg;
		//LogMsgLists(re);
		
		msg = new TimeStampedMessage("bob","Reply",null);
		msg.set_source("charlie");
		msg.set_seqNum(5);
		
		re.applyReceiveRules(msg);
		//assert re.getRcvdMsg() == null;
		LogMsgLists(re);
		
		msg = new TimeStampedMessage("daphnie","Reply",null);
		msg.set_source("charlie");
		msg.set_seqNum(5);
		
		re.applyReceiveRules(msg);
		//assert re.getRcvdMsg() == null;
		LogMsgLists(re);
		
		msg = new TimeStampedMessage("daphnie","Reply",null);
		msg.set_source("bob");
		msg.set_seqNum(5);
		
		re.applyReceiveRules(msg);
		//assert re.getRcvdMsg() != null;
		LogMsgLists(re);
		
		System.out.println(re.getRcvdMsg());
		System.out.println(re.getRcvdMsg());
		System.out.println(re.getRcvdMsg());
	}

}
