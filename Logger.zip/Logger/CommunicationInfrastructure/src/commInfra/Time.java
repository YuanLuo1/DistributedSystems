package commInfra;

public interface Time {
	public void tick();
	public boolean happensBefore(Time time);
	public boolean isConcurrent(Time time);
	public String toString();
}
