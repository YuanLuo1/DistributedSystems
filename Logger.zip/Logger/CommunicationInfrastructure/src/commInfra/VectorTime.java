package commInfra;

public class VectorTime implements Time{
private int vectorSize;
private int[] Counters;
private int myId;

public VectorTime(int proc,int Id){
	vectorSize=proc;
	myId=Id;
	Counters=new int[vectorSize];
	for(int i=0;i<vectorSize;i++){
		Counters[i]=0;
	}
	Counters[myId]=1;
}

public void tick(){
	Counters[myId]++;
}

public int[] getVectorTime(){
	return Counters;
}

public void setVectorTime(int[] value){
	for(int i=0;i<vectorSize;i++){
		Counters[i]=value[i];
	}
}

public int getVectorSize(){
	return vectorSize;
}
	public boolean isConcurrent(Time time){
		//VectorTime t=(VectorTime) time;
		if(isEqual(time))
			return false;
		if(happensBefore(time))
			return false;
		if(happensAfter(time))
			return false;
		return true;
	}
	@Override
	public boolean happensBefore(Time time) {
		// TODO Auto-generated method stub
		VectorTime t=(VectorTime) time;
		if(isEqual(time))
			return false;
		for (int i=0;i<vectorSize;i++){
			if(Counters[i]>t.Counters[i])
				return false;
		}
		return true;
	}
	public boolean happensAfter(Time time){
		VectorTime t=(VectorTime) time;
		if(isEqual(time))
			return false;
		if(happensBefore(time))
			return false;
		for (int i=0;i<vectorSize;i++){
			if(Counters[i]<t.Counters[i])
				return false;
		}
		return true;
	}
	
	public boolean isEqual(Time time){
		VectorTime t=(VectorTime) time;
		for(int i=0;i<vectorSize;i++){
			if(Counters[i]!=t.Counters[i])
				return false;
		}
		return true;
	}
	
	public String toString(){
		String str="";
		for(int i:Counters){
			str=str+i+" ";
		}
		return str;
	}

}

