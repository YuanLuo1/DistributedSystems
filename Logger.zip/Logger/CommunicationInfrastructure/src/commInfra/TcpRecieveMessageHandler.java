/**
 * 
 */
package commInfra;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * @author PhaniShankar
 * Handles incoming messages from other applications
 */
public class TcpRecieveMessageHandler implements Runnable {

	MessagePasser mp;
	Socket clientSocket;
	
	/**
	 * @throws IOException 
	 * 
	 */
	public TcpRecieveMessageHandler(MessagePasser mp, Socket clientSocket ) throws IOException {
		this.mp = mp;
		this.clientSocket = clientSocket;		
	}

	@Override
	public void run() {
		ObjectInputStream in;
		try {
			in = new ObjectInputStream(clientSocket.getInputStream());
		} catch (IOException e1) {
			e1.printStackTrace();
			System.out.println("Reading from client socket failed");
			/*kill the thread*/
			return;
		}
		
		while (false == mp.isAppStopped){
			try {				
				TimeStampedMessage msg = (TimeStampedMessage)in.readObject();
				String src = msg.source;
				/* Synchronize access to this code */
				synchronized(mp.connectionMapLock){
					if (false == mp.connectionMap.containsKey(src)){
						ObjectOutputStream out = new ObjectOutputStream(clientSocket.getOutputStream());
						ConnectionProperties cp = new ConnectionProperties(clientSocket,0,msg.getTimeStamp(), out);
						mp.connectionMap.put(src,cp);
					}
					else{
						assert (mp.connectionMap.get(src).socket == clientSocket);
						if (mp.connectionMap.get(src).socket != clientSocket){
							System.out.println("WARNING: Duplicate connections detected for node "+ src);
						}
					}
				}		 
				if (msg.kind.equals("MP_CONNECTION_SETUP")) {
					/* MP_CONNECTION_SETUP is a special message sent as soon as TCP connection is setup
					 * to create context in the peer node */
					continue;
				}
				mp.re.applyReceiveRules(msg);
			} catch (ClassNotFoundException | IOException e) {
				System.out.println("oops! Something wrong with the connections to peers. Please restart the test harness");
				mp.isAppStopped = true;
				return;
			}			
		}		
	}
}
