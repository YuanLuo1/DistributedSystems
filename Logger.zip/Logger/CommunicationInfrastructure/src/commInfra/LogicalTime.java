package commInfra;

public class LogicalTime implements Time{
	private int Counter;
	
	public LogicalTime(){
		Counter=0;
	}
	public void tick(){
		Counter++;
	}
	public int getLogicalTime(){
		return Counter;
	}
	public void setLogicalTime(int value){
		Counter=value;
	}
	@Override
	public boolean happensBefore(Time time) {
		// TODO Auto-generated method stub
		LogicalTime t=(LogicalTime) time;
		if (Counter<t.Counter){
			return true;
		}
		return false;
	}
	public String toString(){
		return ""+Counter;
	}
	@Override
	public boolean isConcurrent(Time time) {
		// TODO Auto-generated method stub
		System.out.println("Logical clock limits in concurrent messages");
		return false;
	}
}
