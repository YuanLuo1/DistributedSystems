/**
 * 
 */
package commInfra;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * @author PhaniShankar
 * Class is responsible for establishing connections with peer applications and initializing state
 */
public class TCPConnectionCoordinator implements Runnable{
	
	/**
	 * 
	 */
	MessagePasser mp;
	String ip, peerProcessName;
	int port;
	public TCPConnectionCoordinator(MessagePasser mp,String ip, int port, String peerProcessName) {
		this.mp = mp;
		this.ip = ip;
		this.port = port;
		this.peerProcessName = peerProcessName;
	}

	@Override
	public void run() {
		Socket socket;
		while (mp.isAppStopped == false){
			try {
				socket = new Socket(ip, port);
			}			
			catch (IOException e) {
				/* peer not yet up */
				System.out.println("Attempting to connect to "+ peerProcessName + " failed. Retrying ...");
				try {
					Thread.sleep(20000);
				} catch (InterruptedException e1) {
					e1.printStackTrace();
				}
				socket = null;
			}
			if (null == socket) continue;
			
			ObjectOutputStream out;
			try {
				out = new ObjectOutputStream(socket.getOutputStream());
			} catch (IOException e2) {
				System.out.println("socket output stream corrupted. Re-open socket");
				try {
					socket.close();
				} catch (IOException e) {
				
				}
				continue;
				
			}
			ConnectionProperties cp = new ConnectionProperties(socket,0,mp.cs.getTimeStamp().getTime(),out);
						
			/*synchronize access to connection Map */
			synchronized(mp.connectionMapLock){
				if (false == mp.connectionMap.containsKey(peerProcessName)){
					mp.connectionMap.put(peerProcessName,cp);
					System.out.println("Connection established with " + peerProcessName);							
				}
				else{
					System.out.println("WARNING: Duplicate connections detected for node "+ peerProcessName);
				}	
			}
			
			/*Send a special message to create entry at the peer */
			Message msg = new Message(peerProcessName,"MP_CONNECTION_SETUP","");
			msg.set_source(mp.processName);
			msg.set_seqNum(0);
			try {
				cp.outputStream.writeObject(msg);
				cp.outputStream.flush();
			} catch (IOException e1) {
				System.out.println("Something really bad happened. Unable to write to socket. Close and re-open");
				try {
					socket.close();
				} catch (IOException e) {
					
				}
				/* Start from the beginning */
				continue;
			}
			
			/* create a thread to handle the receive messages */
			TcpRecieveMessageHandler handler;
			try {
				handler = new TcpRecieveMessageHandler(mp,socket);
			} catch (IOException e) {
				System.out.println("Unable to create the handler. close and re-open connection");
				try {
					socket.close();
				} catch (IOException e1) {
					
				}
				continue;
				
			}
			Thread clientThread = new Thread(handler);
			clientThread.start();
			
			break;
		}
		
	}
}
