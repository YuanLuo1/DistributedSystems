/**
 * 
 */
package commInfra;

import java.io.*;
import java.net.ConnectException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.*;
import java.util.logging.Logger;

import com.dropbox.core.DbxException;

/**
 * @author Yuan Luo
 * Class responsible for facilitating an environment where applications can send messages to other applications
 * running on other nodes. In addition, fine grained control of message passing can be achieved using 
 * rule specifications in configuration file
 */
public class MessagePasser {
	String  configFile;
	String  processName;
	String timing;
	ConfigurationManger cm;
	ClockService cs;
	RulesEngine re;
	Map <String, ConnectionProperties> connectionMap = null;
	Object connectionMapLock;
	ServerSocket serverSocket;
	boolean isAppStopped;
	
	/**
	 * @throws DbxException 
	 * @throws IOException 
	 * 
	 */
	public MessagePasser(String configurationFilename, String localName) throws IOException, DbxException {
		this.configFile = configurationFilename;
		this.processName = localName;
		connectionMap = new HashMap<String,ConnectionProperties>();
		serverSocket = null;
		isAppStopped = false;
		connectionMapLock = new Object();
		
		/* Initialize CM and RE and read the configuration data */
		cm = new ConfigurationManger(configurationFilename,localName);
		re = new RulesEngine(cm);		
		//System.out.println(cm.configDict);
		if (cm.configDict == null){
			System.out.println("Empty configuration");
			System.exit(0);
		}
		List initialConfig = (List)cm.configDict.get("configuration");	
		try{
			setUpTCPConnections(initialConfig,localName);
			//System.out.println("Setup complete");
		}
		catch(IOException | InterruptedException e){
			System.out.println("TCP Connection setup failed");
			isAppStopped = true;	
		}
	}

	void send(TimeStampedMessage timestmpMsg){
		
		ConnectionProperties cp = null; 
		cp = connectionMap.get(timestmpMsg.destination);
		
		if (null == cp ){
			System.out.println("WARNING: Attempting to send message to " + timestmpMsg.destination + " on non-existant connection ");
			return;
		}
		timestmpMsg.set_seqNum(cp.getSeqNum());
		//timestmpMsg.set_timeStamp(cp.getTimeStamp());
		cp.incSeqNum();
		timestmpMsg.set_source(this.processName);
		
		try {
			ArrayList<TimeStampedMessage> msgList = re.applySendRules(timestmpMsg);
			if (null == msgList){
				/* Message delayed or dropped. No action needed */
				return;
			}
			else{
				timestmpMsg.set_dest("logger");
				msgList.add(timestmpMsg);
				for (TimeStampedMessage msg: msgList){
					/*Get the socket based on the destination */
					cp = connectionMap.get(msg.destination);
					if (null == cp ){
						System.out.println("WARNING: Attempting to send message to " + msg.destination + " on non-existant connection ");
						continue;
					}					
					/* send the message on the socket */
					cp.outputStream.writeObject(msg);
					cp.outputStream.flush();
				}
			}
			
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("Unable to send message : "+timestmpMsg);
		}
		
	}
	TimeStampedMessage receive(){
		return re.getRcvdMsg();
		}
	public ArrayList<TimeStampedMessage> receiveLog(){
		return re.getRcvdLog();
	}
	  
	private boolean setUpTCPConnections(List initialConfig, String localProcessName) throws InterruptedException, IOException{
		for (int i =0; i < initialConfig.size();i++){
			Map configEntry = (Map)initialConfig.get(i);	
			String name = (String) configEntry.get("name");
			if (name.equals(localProcessName)){
				/*current process configuration. Open a TCP server at configured port */
				int port = (int)configEntry.get("port");
				try {
					serverSocket =  new ServerSocket(port);
					TcpServer server = new TcpServer(serverSocket,this);
					Thread serverThread = new Thread(server);
					serverThread.start();
					break;
				} catch (IOException e) {					
					System.out.println("Unable to create a TCP server. Initialization failed");
					return false;
				} 
			}			
		}
		
		for (int i =0; i < initialConfig.size();i++){
			Map configEntry = (Map)initialConfig.get(i);
			String name = (String) configEntry.get("name");
			/* Every process will establish connection with every other process whose 
			 * name is lexicographically greater than current process name*/
			if (name.compareTo(localProcessName) > 0){
				/*create a connection with peer process */
				String ip = (String) configEntry.get("ip");
				int port = (int)configEntry.get("port");
				TCPConnectionCoordinator tcc = new TCPConnectionCoordinator(this,ip,port,name);
				Thread tccThread = new Thread(tcc);
				tccThread.start();
			}			
		}	
		return true;
	}
}
