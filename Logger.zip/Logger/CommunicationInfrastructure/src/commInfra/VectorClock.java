package commInfra;

public class VectorClock extends ClockService {
	
	public VectorClock (int numProc, int Id){
		super(numProc, Id);
	}
	public TimeStamp getTimeStamp(){
		return super.timeStamp;
	}
	
	public void tick(){
		((VectorTime)super.timeStamp.getTime()).tick();
		//super.timeStamp.getTime().tick();
	}
	public void sendAction(){
		tick();
	}
	public void receiveAction(TimeStamp ts){
		VectorTime t=(VectorTime)super.timeStamp.getTime();
		VectorTime t2=(VectorTime) ts.getTime();
		int size=t.getVectorSize();
		int[]values=new int[size];
		for(int i=0;i<size;i++){
			values[i]=Math.max(t.getVectorTime()[i], t2.getVectorTime()[i]);
		}
		t.setVectorTime(values);
		tick();
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.timeStamp.getTime().toString();
	}
	
}
