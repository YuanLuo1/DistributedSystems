package commInfra;

@SuppressWarnings("serial")
public class TimeStampedMessage extends Message{
		Time timestamp;
		String tag;
		
		/**
		 * 
		 */
		
		public TimeStampedMessage(String dest, String kind, Object data) {
			super(dest, kind, data);
			this.kind = kind;
			this.destination = dest;
			this.data = data;
			this.tag=null;
		}
		public Time getTimeStamp(){
			return timestamp;
			
		}
		public void set_timeStamp(Time timeStamp){
			this.timestamp = timeStamp;
			
		}
		public void set_dest(String destination){
			this.destination=destination;
			
		}
		public void set_tag(){
			this.tag="concurrent";
			
		}
		@Override
		public String toString(){
			String msg = "Source: "+ source + ", Dest: "+ destination + ", kind: "+kind +", seqNum: "+ seqNum +",timestamp: "+timestamp +", tag: "+tag;
			if (null != data){
				msg = msg + " data: "+ data;
			}
			return msg;
		}
	

}
