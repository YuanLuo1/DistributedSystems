package commInfra;

import java.util.Comparator;

@SuppressWarnings("rawtypes")
public class SortByTimeStamp implements Comparator{

	@Override
	public int compare(Object arg0, Object arg1) {
		TimeStampedMessage msg0 = (TimeStampedMessage) arg0;
		TimeStampedMessage msg1 = (TimeStampedMessage) arg1;
		if (!msg0.getTimeStamp().happensBefore(msg1.getTimeStamp()))
		return 1;
		if(msg0.getTimeStamp().isConcurrent(msg1.getTimeStamp())){
			msg0.set_tag();
			msg1.set_tag();
		}
		return 0;
	}

}
