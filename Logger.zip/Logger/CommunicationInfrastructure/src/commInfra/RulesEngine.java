/**
 * 
 */
package commInfra;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * @author PhaniShankar
 * Class responsible for enforcing rules present in the configuration file
 */
public class RulesEngine {
	
	/* delayed message queues*/
	ArrayList<TimeStampedMessage> delayedRcvdMsgList;
	ArrayList<TimeStampedMessage> delayedSendMsgList;
	/* received message queue*/
	ArrayList<TimeStampedMessage> rcvdMsgList;
	
	private Object sendListLock = new Object(); // lock for sendList related Operations
	private Object rcvdListLock = new Object(); // lock for rcvdList related Operations
	
	ConfigurationManger cm;
	ClockService cs;
	
	/**
	 * 
	 */
	public RulesEngine(ConfigurationManger cm) {
		this.cm = cm;
		delayedSendMsgList = new ArrayList<TimeStampedMessage>();
		delayedRcvdMsgList = new ArrayList<TimeStampedMessage>();
		rcvdMsgList = new ArrayList<TimeStampedMessage>();
	}	
	
	private String matchRules(Message msg, List rules){
		/* retrieve the parameters from the message */
		String src    = msg.get_Source();
		String dst    = msg.get_destination();
		String kind   = msg.get_kind();
		int    seqNum = msg.get_seqNum();
		String action = "none";
		
		if (null == rules){
			System.out.println("empty rules");
			return action;
		}
		
		for (int i = 0; i < rules.size(); i++){
			Map rule = (Map) rules.get(i);
			if (rule.containsKey("src") && (false == ((String)rule.get("src")).equals(src))){
				continue;
			}
			if (rule.containsKey("dest")&& (false == ((String)rule.get("dest")).equals(dst))){
				continue;
			}
			if (rule.containsKey("kind")&& (false == ((String)rule.get("kind")).equals(kind))){
				continue;
			}
			/* For dropAfter rule, sequence number is necessary. However, if it is missing, we drop all msgs*/
			if (rule.containsKey("seqNum")&& ((int)rule.get("seqNum")!= seqNum)){
				action = (String) rule.get("action");
				if (action.equals("dropAfter")&&
						seqNum > (int)rule.get("seqNum")){
					break;
				}
				action = "none";
				continue;
			}	
			else{
				/* for drop after, same sequence number does not match. 
				 * Also if no sequence number is provided, we ignore the rule */
				if (((String) rule.get("action")).equals("dropAfter")){
					action = "none";
					continue;
				}
			}
			action = (String) rule.get("action");
			break;
		}		
		return action;
	}
	public ArrayList<TimeStampedMessage> applySendRules(TimeStampedMessage msg) throws IOException{

		ArrayList<TimeStampedMessage> msgList = new ArrayList<TimeStampedMessage>();

		Map<String,List> config_dict = cm.checkForUpdates();
		List sendRules = config_dict.get("sendRules");
		String action = matchRules(msg,sendRules);
		
		synchronized(sendListLock){
			switch(action){
			case "drop":       /* No need to add message. Return empty list*/
							   	System.out.println("action: drop");
						        break;
				
			case "dropAfter":  /* No need to add message. Return empty list*/
							   	System.out.println("action: dropAfter");
							   	break;
			
			case "delay":      /*Instead of sending the msg add to delay queue*/
							   	System.out.println("action: delay");
							   	delayedSendMsgList.add(msg);
							   	break;
							   
			default:  		   /* No rule matched. If there are any delayed msgs,
			 					  send them as well */
							   	System.out.println( "action: none");
							   	if (false == delayedSendMsgList.isEmpty()){
							   		msgList = (ArrayList<TimeStampedMessage>) delayedSendMsgList.clone();
							   		delayedSendMsgList.clear();
							   	}
							   	/* Add non-delayed message at the beginning of the list*/
							   	msgList.add(0,msg);
							   	break;
			}
		}

		return msgList;
	}
	
	public void applyReceiveRules(TimeStampedMessage msg) throws IOException{
		Map<String,List> config_dict = cm.checkForUpdates();
		List recvRules = config_dict.get("receiveRules");
		String action = matchRules(msg,recvRules);
		
		synchronized(rcvdListLock){
			switch(action){
			case "drop":       /* No need to handle the message */
								System.out.println("action: drop");
						        break;
												
			case "dropAfter":  /* No need to handle the message */
								System.out.println("action: dropAfter");
								break;
			
			case "delay":      /*Instead of adding to receive queue, add to delay queue*/
								System.out.println("action: delay");
								delayedRcvdMsgList.add(msg);
								break;
							   
			default:  		   /* No rule matched. If there are any delayed msgs, process them */
							   	System.out.println( "action: none");	
							   	rcvdMsgList.add(msg);
							   	if (false == delayedRcvdMsgList.isEmpty()){
							   		rcvdMsgList.addAll(delayedRcvdMsgList);
							   		delayedRcvdMsgList.clear();
							   	}					
							   	break;
			}
		}
	}
	public TimeStampedMessage getRcvdMsg(){
		TimeStampedMessage msg = null;
		synchronized(rcvdListLock){
			if (false == rcvdMsgList.isEmpty()){
				msg = rcvdMsgList.remove(0);
			}
		}
		return msg;
	}

	@SuppressWarnings("unchecked")
	public ArrayList<TimeStampedMessage> getRcvdLog(){
		Collections.sort(rcvdMsgList, new SortByTimeStamp());
		//cs.SortRecvMsg(rcvdMsgList);
		return rcvdMsgList;
	}
}
